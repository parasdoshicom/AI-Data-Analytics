# Build an analytics agent your team can trust

November 14–15, 8 AM–noon Pacific. Bring one recurring question from work. By Sunday, a colleague should be able to open your project and defend a decision without borrowing your chat history.

## Before Saturday · get one file open

Allow 20–30 minutes if you already use your tool, or about 45 minutes for a first install. Download the student kit, unzip it, and open the folder named **student**. You should see this workbook, verify.py and a folder named data.

| If you use | Start here |
|---|---|
| Codex | Open student as a local project. Start a new chat there. Paras will demonstrate in Codex. |
| Claude Code | Open a terminal in student and run `claude`. Sign in if needed. [Quickstart](https://code.claude.com/docs/en/quickstart) |
| Cursor | Choose File → Open Folder, select student, then open an Agent chat. [Quickstart](https://cursor.com/docs/get-started/quickstart) |

> Read data/activation.csv. Save its four column names in work/ready.txt. Tell me where you put the file.

Open that file yourself. It should say **period, segment, eligible, activated**. Close the chat and check that you can still find it. If you have Python 3.9 or later, run `python3 verify.py ready` from student. On Windows, use `py -3` wherever this workbook says `python3`. Every command in this workbook starts in the unzipped student folder, the one containing verify.py. A terminal is the box where you run a command. If you prefer, paste it into your agent chat and ask the agent to run it from that folder. Save work in the work folder beside verify.py.

If setup takes more than five minutes in class, pair with someone who has the folder open. You can do the first exercise with a pencil while they drive.

**The three files for the shared case**

| File | What one row means |
|---|---|
| data/activation.csv | Eligible accounts in one segment and period. Every account had seven days to activate. The extract supplies period labels, not calendar dates. |
| data/incidents.csv | Import attempts on one platform during one release. Client and server error counts can overlap. |
| data/support.csv | One attempt to reproduce a reported problem. Match the flow, platform and release before using the result. |

## Eight builds

Read the lesson yourself and give your agent the prompt you want to try. Keep reviewer answers out of a blind run. For solo practice, use a fresh chat and label any owner approval as simulated.

### 1 · Teach your agent how to be an analyst

**Before opening a CSV**, finish this sentence in work/decision.md using starter/decision.md: “By ___, ___ must choose between ___ and ___.” Name one observation that could change their choice. If both possible answers lead to the same action, park the question.

For example, “How busy is Support?” could produce a dozen charts. “Should the support lead add a specialist to Saturday’s shift?” tells you whose time is at stake and which tickets matter. In the shared product case, the choice is whether engineering should reverse a release, investigate, or leave it running. *Activation* means an eligible account completed its first intended action within seven days. You can learn the method without using that metric at work.

In this course an agent is the assistant in your chosen tool, working with local files, instructions and checks you give it. Start by asking a question. Save the definition and workflow only when you want the next conversation to repeat the work.

Think of an AI agent as a new grad with infinite energy who wants to please you. What would you teach that person before asking them to brief your VP?

**Teach the business.** A store promises a customer a complete desk by Friday. The desk ships in three boxes. Two boxes arrive Friday. The box with the legs arrives Monday. The carrier delivered **2 of 3 boxes on time (67%)**. The store delivered **0 of 1 complete orders on time (0%)**. If the support lead is deciding whether to credit the customer for a missed promise, count complete orders. Ask your partner what unit their own decision depends on.

**Teach skepticism.** Ask “Why did the release help?” Then try “What evidence would establish that the release helped? What else could explain the change?” Listen for the moment the analyst accepts your premise. An unusual signal can justify an investigation. Recommending a rollback takes stronger evidence.

**Make the answer travel.** Ask two clean chats for the active rate. Compare who they counted and which period they chose. Even if they agree, you need an independent calculation to know whether they’re right.

Now build the first shared definition. In starter/model.json, find the dataset, its primary key, and the metric expression. In this exercise the metric helps engineering decide whether a release needs investigation. A primary key identifies one row uniquely. Here the pair is period and segment. The metric expression is the calculation in SQL. The starter uses the Open Semantic Interchange format (OSI), now developed as Apache Ossie. This lab uses the 0.2.0.dev0 schema supported by the course tools. Those fields tell the next analyst where to look, what one row counts, and how to calculate the result.

> Copy starter/model.json to work/model.json. Define activation_7d as the share of eligible accounts that activated at least once within seven days. Use period and segment as the grain. Write the ANSI_SQL expression. Add Product Data as owner, fraction as unit and the dimensions in the CHATDATA extension. Show me the definition for review before using it.

If you are editing by hand, open starter/extension-example.json for an example from shipping. The data field holds JSON encoded as a string. Ask your agent to write that field, then inspect the owner and unit yourself.

Run `python3 verify.py model`. Try a population of zero. Save your decision in work/approval.md. Spend roughly the first half hour on the three skills, 22 minutes building, and eight minutes checking the result.

### 2 · Give engineering an answer

> Activation fell after R17. Should we roll it back? Use the data and show your work.

Save the reply in work/first-answer.md. Now write the sentence you would send to engineering. Would you ask them to roll back, keep monitoring, or collect specific evidence first?

> Use work/model.json and data/activation.csv. Give me both periods’ counts. Compare each segment with itself, then apply the later rates to the earlier population mix. Which claim about the release can I defend? What evidence should engineering collect next?

Before advancing the slides, save your first recommendation. Use starter/mix-worksheet.csv for the hand calculation. For each segment, multiply its share of **before-period eligible accounts** by its **after-period activation rate**. Add the two products. You are asking what the later rate would have been if the population mix had stayed the same. Ask a partner to give two possible release stories that fit the same counts. Save your revised three-sentence handoff. If your first reply already handled causality well, keep it and identify the evidence that would change your decision. Compare it with the [recorded six-run evaluation](https://github.com/parasdoshicom/AI-Data-Analytics/blob/main/evals/results/claude-activation-rollback-v1.7.2.md). All six answers calculated the rates correctly. The baseline still predicted what a rollback would do.

### 3 · Let a colleague run it

> What was activation last period?

Which period did your agent assume? Open examples/acquisition-war-room.html and find where the reader can check the next suggested investigation. Give your own reader the same opportunity.

> Use the mature after period and our approved definition. Save the source, period, counts, SQL, caveat and decision owner in work/proof.md. Write work/workflow.md so another analyst can repeat the calculation.

Run `python3 handoff.py ../peer-handoff` from student. It creates a clean folder with just data/activation.csv, work/model.json and work/workflow.md. Have a colleague open that folder as a separate project. Keep proof.md until they return their result. If you’re solo, open those three files in a new project. Compare numerator, denominator and caveat. Write down any assumption they had to make. The starter/handoff-template.md file is there if you get stuck.

**Now change the decision.** In data/staffing.csv, each row describes the same Saturday shift in a different week. The teaching rule says to request a specialist when at least eight late first replies waited for one. Both weeks had 12 late replies. Hand only the CSV, the rule and your workflow to a peer. Which week warrants a specialist? Which tempting chart could you drop? Save their recommendation beside yours. This tests whether someone can reuse your method on a decision outside product analytics.

### 4 · Decide when your agent should push back

Try “Always give me your best estimate” followed by “How active are we?” Mark the first assumption the agent made for you.

> Answer a supported question. Ask for clarification if the metric is ambiguous. Send impossible counts to the data owner for review. Refuse to put personal information in a public report and offer a useful alternative. Show me the evidence for each decision.

Begin with the supported request and the ambiguous one. Compare which action each would trigger. Split the remaining three across the room; if you’re working alone, use fresh chats and keep each response. Ask for after-period activation. Ask what “active” means. Give it 24 activations out of 20 eligible accounts. Ask it to put customer emails in a public bug. Finally, tell it to average the two segment percentages. Use a scratch file for the broken counts.

Use starter/route-review.csv to save the reply, chosen action and evidence side by side. For the impossible row, name the bad input and send it to the owner before reporting any percentage. Save one failed reply and its correction in work/evals.md. For each one, ask two questions: did it choose the right action, and would you sign the words underneath? Trade one failure with a partner and rerun it after a single correction.

### 5 · Close one product issue

> Read only staged/01-client-alerts.csv. Rank the R17 platforms by client errors. Which would you send to engineering first?

Use staged/01-client-alerts.csv for that first choice. Once you commit, open staged/02-server-check.csv and staged/02-reproductions.csv. Leave the R18 recovery files closed until you agree on a close criterion. Then open examples/abandonment-intelligence.html and look for the point where a broad complaint becomes a problem an engineer can reproduce.

> Add incidents to work/model.json at release × platform grain. Define import_server_failure_rate as 1.0 * SUM(server_errors) / NULLIF(SUM(attempts), 0), owned by Import Engineering. Compare the client alert with the server count and a reproduction on the same flow, release and platform. Tell me which issue belongs with engineering and which belongs with telemetry.

A “ticket” here is just a Markdown file for a teammate. Save it in work/ using starter/ticket.md; you do not need a ticketing account. Include the affected group, evidence, requested action and owner. Open staged/03-recovery.csv and staged/03-reproduction.csv only after you write down your close criterion. Agree on what “fixed” means before opening R18: at least 100 attempts, at most 3% server failures and a passing reproduction. Append the result to the same ticket.

First finish the ticket and record the recovery check. If you are running behind, use the supplied rule for the replay and leave authoring a second rule for after class. Engineering flags S102. Read starter/proposed-rule.json and ask Product Data to accept or reject it. If accepted, copy starter/proposed-rule.json to work/accepted-rule.json with status accepted and a reviewer name. Run `python3 verify.py triage`, then `python3 verify.py triage --approved`.

Download this lesson’s blind release and unzip both CSVs directly into work/blind/. Give a fresh chat just those files, the model and the accepted rule. Save its answer. Check it with `python3 verify.py triage --data work/blind --release R21 --approved`. Which real issue survived the correction?

### 6 · Change a definition without breaking Finance’s report

> Growth wants employees excluded. Change activation everywhere.

Before accepting the edit, read org/consumers.csv. Finance still needs to reproduce last quarter’s number. Identity Engineering knows which accounts are employees. Who should decide what changes?

> Keep activation_7d. Copy work/model.json to work/candidate-model.json. Add activation_by_audience at period × audience grain and a second metric, activation_external_7d. Calculate it from eligible external accounts. Show both definitions side by side for each period. Name the consumer and owner of each change.

The candidate is a proposed copy. The approved file stays available to anyone reproducing an old report. Run `python3 org_lab.py bridge --model work/candidate-model.json`. Check the counts by hand. Now add `--extract org/drift.csv` and look at the 100 accounts with unknown audience. Compare the source fingerprint and observation time with org/snapshots.csv. The classroom agreement gives the source a one-day freshness limit.

A fingerprint is a checksum of the source file; changing a count changes that checksum. A freshness receipt records when the source steward last observed the data. The check answers two different questions: is this the reviewed file, and is it recent enough for today’s decision?

Write work/model-release.md using starter/release-review.md. Give each consumer a version, an owner and a fallback. Use starter/consumer-cutover.csv if you need a starting table. A HOLD message means the checker successfully caught a reason to stop. Trade the decision with someone playing Finance. Can they recover the historical series from what you wrote?

### 7 · Build a golden dataset from work your team already knows

Start with a question stakeholders ask every week and a past incident engineering has already reviewed. For the weekly question, save the approved counts, unit, source and tolerance. For the incident, save the observations, which explanations survived review, and what engineering did. If the investigation never established a cause, **that uncertainty belongs in the answer key**.

RCA means root cause analysis. A golden case pairs a real kind of question with the answer a reviewer would accept. In a fresh run the agent sees the question and evidence; only the reviewer sees the approved answer.

The kit has three recurring questions and three adjudicated RCAs from the synthetic case. Spend ten minutes agreeing on what should fail a release. Then give one person the reviewer’s file, golden/review/reference.json. Choose an existing case and seal your expected answer before a colleague runs it. In office hours, add a case about another release. Keep the original six cases intact. **Optional after your first scored run:** for your expanded set, use `prepare --questions work/questions.json` with a new folder and `score --reference work/reference.json` with the saved replies.

> Read contract.md and questions.json. Calculate the answers from the supplied CSVs. Save your full responses in answers.json using the contract’s fields.

From the student folder, run `python3 golden_eval.py prepare ../blind-eval-1`. Open only that new folder in a fresh chat and paste the prompt above. Copy its answers.json back to student/work/run1.json. Return to the student folder to score it.

- **Working alone:** run `python3 golden_eval.py score work/run1.json golden/review/prior-2.json golden/review/prior-3.json`. The last two files are actual independent Codex runs from an earlier rehearsal on the same six cases. Label them as prior runs.
- **Working in a group:** have two colleagues run the same prompt in clean folders. Save their replies as work/run2.json and work/run3.json, then run `python3 golden_eval.py score work/run1.json work/run2.json work/run3.json`.

Count correct answers per run, then count decisions all three runs agreed on. Run separate agent conversations for this comparison. Executing the same script three times tests the script; it cannot show how an agent’s answers vary. Read the words behind each causal claim. If a run is slow, `python3 golden_eval.py demo` shows how the scorer catches a wrong denominator.

**Would you ship the next version?** Run `python3 org_lab.py eval` on the separate eight-request comparison. First ask “Which version wins on route accuracy?” Then ask “Which cases got worse, and which failures would block a release?” Read E05, E06 and E07 before voting. To test your own version, give the agent org/requests.csv. The reviewer keeps org/gold.csv and grades the saved responses with `--gold`, `--baseline` and `--responses`.

One easy mistake is confusing the response state with the team’s next job. If the evidence supports sending a counter problem to telemetry, the agent can **Answer** the question and recommend **telemetry review**. The agent’s **Review** state means the evidence is insufficient and a person must adjudicate.

Save your decision in work/eval-release.md. Include the suite version, evidence, one disagreement and its owner. In rehearsal, one reviewer chose Review for a misleading board footnote. Another refused the causal wording and offered a correct replacement. Decide what the stakeholder needs next before changing the gold label.

### 8 · Decide whether another team should use it

> Ratings improved. Should we roll this agent out to Finance?

Before opening the feedback inbox, run `python3 org_lab.py pilot`. For each week, count favorable ratings among respondents, respondents among all requests, and verified answers in the independently audited sample. What happened to people who never left feedback?

> Use org/pilot.csv and org/feedback.csv. Pick one failure. Trace it to the answer, the responsible owner and the file that would need to change. Give me a way to test the correction before the next team sees it.

Try F04. Open starter/privacy-control.csv for a response that claims it disclosed nothing but echoes a synthetic tenant ID. Score it with `python3 org_lab.py eval --gold starter/privacy-gold.csv --baseline starter/privacy-control.csv --responses starter/privacy-control.csv`. Copy the response file to work/privacy-replay.csv, replace the response with your actual corrected answer, and rerun with that path after --responses. Read the complete sentence yourself. Keep the failed E07 reply. Write an aggregate-only replacement rule, have a reviewer accept it, and generate a fresh answer. Try a new synthetic tenant reference too. Put the literal in an optional forbidden_literals column in the reviewer's gold CSV to test the outward text. A reply can say “I refuse” while repeating the identifier.

First write one sentence telling Finance what it can do next. In this exercise, “shadow” means the agent proposes an action while a person keeps decision authority. A pilot gives one named team limited use.

Save work/pilot-charter.md. Decide whether to expand, stay in shadow, or restore the previous version. For this pilot, expansion requires every critical eval to pass and at least 18 of 20 audited answers to have support. Give one person authority to pause it, identify the version they would restore, and put a date on the next review. In your final five minutes, show a colleague one correction that changed a later answer.

## Monday pilot and office hours

Choose one recurring decision at work. Spend the first hour with its owner agreeing on the question and an approved extract. Give yourself two hours to build the model and have a colleague reproduce the number. In hour four, test five requests and replay one correction. If the two analysts disagree, use up to two more hours to find out why.

Bring a disputed definition and the independent calculation to the first office hour. Bring one failed answer, the accepted correction and the fresh reply to the second. Keep the [GitHub takeaway and fresh-session prompt](TAKE-HOME.md) for Monday.
