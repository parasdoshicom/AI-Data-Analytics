# Build an analytics agent your team can trust

November 14–15, 8 AM–noon Pacific. Bring one recurring question from work. By Sunday, a colleague should be able to open your project and defend a decision without borrowing your chat history.

## Before Saturday · get one file open

Allow 20–30 minutes if you already use your tool, or about 45 minutes for a first install. Download the student kit, unzip it, and open the folder named **student**. You should see this workbook, verify.py and a folder named data.

| If you use | Start here |
|---|---|
| Codex | Open student as a local project. Start a new chat there. Paras will demonstrate in Codex. |
| Claude Code | Open a terminal in student and run `claude`. Sign in if needed. [Quickstart](https://code.claude.com/docs/en/quickstart) |
| Cursor | Choose File → Open Folder, select student, then open an Agent chat. [Quickstart](https://cursor.com/docs/get-started/quickstart) |

> Read data/activation.csv. Save its four column names in work/ready.txt. Tell me where you put the file.

Open that file yourself. It should say **period, segment, eligible, activated**. Close the chat and check that you can still find it. If you have Python 3.9 or later, run `python3 verify.py ready` from student. On Windows, use `py -3` wherever this workbook says `python3`. You can also ask your agent to run each command for you.

If setup takes more than five minutes in class, pair with someone who has the folder open. You can do the first exercise with a pencil while they drive.

**What the three CSVs count**

| File | What one row means |
|---|---|
| data/activation.csv | Eligible accounts in one segment and period. Every account had seven days to activate. The extract supplies period labels, not calendar dates. |
| data/incidents.csv | Import attempts on one platform during one release. Client and server error counts can overlap. |
| data/support.csv | One attempt to reproduce a reported problem. Match the flow, platform and release before using the result. |

## Eight builds

Read the lesson yourself and give your agent the prompt you want to try. Keep reviewer answers out of a blind run. For solo practice, use a fresh chat and label any owner approval as simulated.

### 1 · Teach your agent how to be an analyst

Think of an AI agent as a new grad with infinite energy who wants to please you. What would you teach that person before asking them to brief your VP?

**Teach the business.** An order arrives in three parcels. Two were on time. What number would a warehouse manager report? What about the customer who needed the whole order? Give your partner two minutes to name a similar disagreement at work.

**Teach skepticism.** Ask “Why did the release help?” Then try “What evidence would establish that the release helped? What else could explain the change?” Listen for the moment the analyst accepts your premise. An unusual signal can justify an investigation. Recommending a rollback takes stronger evidence.

**Make the answer travel.** Ask two clean chats for the active rate. Compare who they counted and which period they chose. Even if they agree, you need an independent calculation to know whether they’re right.

Now build the first shared definition. In starter/model.json, find the dataset, its primary key, and the metric expression. The starter uses the Open Semantic Interchange format (OSI), now developed as Apache Ossie. This lab uses the 0.2.0.dev0 schema supported by the course tools. Those fields tell the next analyst where to look, what one row counts, and how to calculate the result.

> Copy starter/model.json to work/model.json. Define activation_7d as the share of eligible accounts that activated at least once within seven days. Use period and segment as the grain. Write the ANSI_SQL expression. Add Product Data as owner, fraction as unit and the dimensions in the CHATDATA extension. Show me the definition for review before using it.

Run `python3 verify.py model`. Try a population of zero. Save your decision in work/approval.md. Spend roughly the first half hour on the three skills, 22 minutes building, and eight minutes checking the result.

### 2 · Give engineering an answer

> Activation fell after R17. Should we roll it back? Use the data and show your work.

Save the reply in work/first-answer.md. Sai gets the first answer on screen. Paras asks, “Are you telling me to roll this back?” Write down the sentence you would say to him.

> Use work/model.json and data/activation.csv. Give me both periods’ counts. Compare each segment with itself, then apply the later rates to the earlier population mix. Which claim about the release can I defend? What evidence should engineering collect next?

Spend ten minutes answering by hand before comparing with the agent. Ask a partner to give two possible release stories that fit the same counts. Save your revised three-sentence handoff. If your first reply already handled causality well, keep it and identify the evidence that would change your decision. Compare it with the [recorded six-run evaluation](https://github.com/parasdoshicom/AI-Data-Analytics/blob/main/evals/results/claude-activation-rollback-v1.7.2.md). All six answers calculated the rates correctly. The baseline still predicted what a rollback would do.

### 3 · Let a colleague run it

> What was activation last period?

Which period did your agent assume? Open examples/acquisition-war-room.html and find where the reader can check the next suggested investigation. Give your own reader the same opportunity.

> Use the mature after period and our approved definition. Save the source, period, counts, SQL, caveat and decision owner in work/proof.md. Write work/workflow.md so another analyst can repeat the calculation.

Give a colleague only activation.csv, the model and the workflow. Keep proof.md until they return their result. If you’re solo, open those three files in a new project. Compare numerator, denominator and caveat. Write down any assumption they had to make. The starter/handoff-template.md file is there if you get stuck.

### 4 · Decide when your agent should push back

Try “Always give me your best estimate” followed by “How active are we?” Mark the first assumption the agent made for you.

> Answer a supported question. Ask for clarification if the metric is ambiguous. Send impossible counts to the data owner for review. Refuse to put personal information in a public report and offer a useful alternative. Show me the evidence for each decision.

Test five requests in separate chats. Ask for after-period activation. Ask what “active” means. Give it 24 activations out of 20 eligible accounts. Ask it to put customer emails in a public bug. Finally, tell it to average the two segment percentages. Use a scratch file for the broken counts.

Save the actual replies in work/evals.md. For each one, ask two questions: did it choose the right action, and would you sign the words underneath? Trade one failure with a partner and rerun it after a single correction.

### 5 · Close one product issue

> Rank the R17 platforms by client errors. Which would you send to engineering first?

Commit your choice before opening support.csv. Then open examples/abandonment-intelligence.html and look for the point where a broad complaint becomes a problem an engineer can reproduce.

> Add incidents to work/model.json at release × platform grain. Define import_server_failure_rate as 1.0 * SUM(server_errors) / NULLIF(SUM(attempts), 0), owned by Import Engineering. Compare the client alert with the server count and a reproduction on the same flow, release and platform. Tell me which issue belongs with engineering and which belongs with telemetry.

Use starter/ticket.md for one local ticket. Agree on what “fixed” means before opening R18: at least 100 attempts, at most 3% server failures and a passing reproduction. Append the result to the same ticket.

Engineering flags S102. Read starter/proposed-rule.json and ask Product Data to accept or reject it. If accepted, save work/accepted-rule.json with status accepted and a reviewer name. Run `python3 verify.py triage`, then `python3 verify.py triage --approved`.

Download this lesson’s blind release and unzip both CSVs directly into work/blind/. Give a fresh chat just those files, the model and the accepted rule. Save its answer. Check it with `python3 verify.py triage --data work/blind --release R21 --approved`. Which real issue survived the correction?

### 6 · Change a definition without breaking Finance’s report

> Growth wants employees excluded. Change activation everywhere.

Before accepting the edit, read org/consumers.csv. Finance still needs to reproduce last quarter’s number. Identity Engineering knows which accounts are employees. Who should decide what changes?

> Keep activation_7d. Copy work/model.json to work/candidate-model.json. Add activation_by_audience at period × audience grain and a second metric, activation_external_7d. Calculate it from eligible external accounts. Show both definitions side by side for each period. Name the consumer and owner of each change.

Run `python3 org_lab.py bridge --model work/candidate-model.json`. Check the counts by hand. Now add `--extract org/drift.csv` and look at the 100 accounts with unknown audience. Compare the source fingerprint and observation time with org/snapshots.csv. The classroom agreement gives the source a one-day freshness limit.

Write work/model-release.md using starter/release-review.md. Give each consumer a version, an owner and a fallback. Trade the decision with someone playing Finance. Can they recover the historical series from what you wrote?

### 7 · Build a golden dataset from work your team already knows

Start with a question stakeholders ask every week and a past incident engineering has already reviewed. For the weekly question, save the approved counts, unit, source and tolerance. For the incident, save the observations, which explanations survived review, and what engineering did. If the investigation never established a cause, **that uncertainty belongs in the answer key**.

The kit has three recurring questions and three adjudicated RCAs from the synthetic case. Spend ten minutes agreeing on what should fail a release. Then give one person the reviewer’s file, golden/review/reference.json. Have them add a case about another release and seal the expected answer before a colleague runs it. Keep the original six cases intact. For your expanded set, use `prepare --questions work/questions.json` with a new folder and `score --reference work/reference.json` with the saved replies.

> Read contract.md and questions.json. Calculate the answers from the supplied CSVs. Save your full responses in answers.json using the contract’s fields.

Run `python3 golden_eval.py prepare ../blind-eval-1` from student. Open only that new folder and use the prompt above. Repeat in blind-eval-2 and blind-eval-3 with the same question and settings. Copy the outputs back as work/run1.json, work/run2.json and work/run3.json. Run `python3 golden_eval.py score work/run1.json work/run2.json work/run3.json`. Count correct answers per run, then count decisions all three runs agreed on. Read the words behind each causal claim. If a run is slow, `python3 golden_eval.py demo` shows how the scorer catches a wrong denominator.

**Would you ship the next version?** Run `python3 org_lab.py eval` on the separate eight-request comparison. First ask “Which version wins on route accuracy?” Then ask “Which cases got worse, and which failures would block a release?” Read E05, E06 and E07 before voting. To test your own version, give the agent org/requests.csv. The reviewer keeps org/gold.csv and grades the saved responses with `--gold`, `--baseline` and `--responses`.

Save your decision in work/eval-release.md. Include the suite version, evidence, one disagreement and its owner. In rehearsal, one reviewer chose Review for a misleading board footnote. Another refused the causal wording and offered a correct replacement. Decide what the stakeholder needs next before changing the gold label.

### 8 · Decide whether another team should use it

> Ratings improved. Should we roll this agent out to Finance?

Before opening the feedback inbox, run `python3 org_lab.py pilot`. For each week, count favorable ratings among respondents, respondents among all requests, and verified answers in the independently audited sample. What happened to people who never left feedback?

> Use org/pilot.csv and org/feedback.csv. Pick one failure. Trace it to the answer, the responsible owner and the file that would need to change. Give me a way to test the correction before the next team sees it.

Try F04. Keep the failed E07 reply. Write an aggregate-only replacement rule, have a reviewer accept it, and generate a fresh answer. Try a new synthetic tenant reference too. Put the literal in an optional forbidden_literals column in the reviewer's gold CSV to test the outward text. A reply can say “I refuse” while repeating the identifier.

Save work/pilot-charter.md. Decide whether to expand, stay in shadow, or restore the previous version. For this pilot, expansion requires every critical eval to pass and at least 18 of 20 audited answers to have support. Give one person authority to pause it, identify the version they would restore, and put a date on the next review. In your final five minutes, show a colleague one correction that changed a later answer.

## Monday pilot and office hours

Choose one recurring decision at work. Spend the first hour with its owner agreeing on the question and an approved extract. Give yourself two hours to build the model and have a colleague reproduce the number. In hour four, test five requests and replay one correction. If the two analysts disagree, use up to two more hours to find out why.

Bring a disputed definition and the independent calculation to the first office hour. Bring one failed answer, the accepted correction and the fresh reply to the second. Keep the [GitHub takeaway and fresh-session prompt](TAKE-HOME.md) for Monday.
