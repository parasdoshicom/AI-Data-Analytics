# Run it again on Monday

The class case follows activation. This optional exercise gives you a fresh decision with different data. Try it if you finish a round early, or take it home for Monday. The files are in your student kit and the [course repository](https://github.com/parasdoshicom/AI-Data-Analytics).

### Try a different business in ten minutes

Tomorrow’s backup carrier costs $800. A warehouse dashboard says deliveries are on time. Is that enough for the dispatcher to keep the current carrier? Open the [analyst brief](monday/dispatch-brief.txt) and [delivery scans](monday/dispatch.csv). Write down your call before your partner opens the [contract owner’s receipt](monday/dispatch-owner.txt). Compare your two calls with the [reviewer’s arithmetic](monday/dispatch-review.txt). All four files are in the kit’s monday folder.

### Take one real question to work

Download the [one-page decision brief](monday/decision-brief.md). Bring it to someone who makes a recurring call. Ask, “What would you do differently if this number went the other way?” If neither of you can name an action, choose another question before building the agent. Fill in the first four rows together. Give another analyst the source and your definition. Compare their count with yours before you show either answer to the decision owner.

### Can your colleague pick up where you left off?

Open your completed student folder in a fresh chat. Paste this and hand the reply to someone who missed Sunday.

> Read my model, workflow, accepted rule and pilot decision in work/. Recalculate the blind-release recommendation. Show me the evidence behind the ticket, what changed after engineering’s correction, and what would make you reconsider.

Ask, “Would you open the ticket? Show me what convinced you.” If your colleague needs something that lives only in your chat, put it in the brief and try again.
