# Run it again on Monday

### A separate case to try on your own

Operations can spend $800 to change tomorrow’s carrier. What would you tell the dispatcher? Use the [one-slide case](monday/parcel-case.pdf) as your guide. The [analyst brief](monday/dispatch-brief.txt) and [delivery scans](monday/dispatch.csv) are enough for a first call. Give yourself ten minutes and write down what you counted.

Then ask a partner to read the [contract owner’s receipt](monday/dispatch-owner.txt). Working alone, open it after you have saved your first answer. Use the rest of the brief to turn your decision into a rule, hand it to another analyst, and test it on changed data. Compare your two recommendations with the [reviewer’s arithmetic](monday/dispatch-review.txt) when you’re ready.

### Take one real question to work

Download the [one-page decision brief](monday/decision-brief.md). Bring it to someone who makes a recurring call. Ask, “What would you do differently if this number went the other way?” If neither of you can name an action, choose another question before building the agent. Fill in the first four rows together. Give another analyst the source and your definition. Compare their count with yours before you show either answer to the decision owner.

### Can your colleague pick up where you left off?

Open your completed student folder in a fresh chat. Paste this and hand the reply to someone who missed Sunday.

> Read my model, workflow, accepted rule and pilot decision in work/. Recalculate the blind-release recommendation. Show me the evidence behind the ticket, what changed after engineering’s correction, and what would make you reconsider.

Ask, “Would you open the ticket? Show me what convinced you.” If your colleague needs something that lives only in your chat, put it in the brief and try again.
