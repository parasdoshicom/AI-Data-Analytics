# Run it again on Monday

Start with the [course GitHub repository](https://github.com/parasdoshicom/AI-Data-Analytics). The slides, student kit and synthetic checks are there. If you want the source on your laptop, choose Code → Download ZIP.

Open your completed student folder in a fresh chat. Try this before you introduce any company data:

> Read my model, workflow, accepted rule and pilot decision in work/. Recalculate the blind-release recommendation. Show me the evidence behind the ticket, what changed after engineering’s correction, and what would make you reconsider.

Give the answer to a colleague who missed the course. If they can trace it to the right source and explain the decision, pick a recurring question the two of you can try at work. For more practice with synthetic data, run `python3 plugins/chatdata/scripts/doctor.py` from the GitHub repository root (Python 3.9 or later).
