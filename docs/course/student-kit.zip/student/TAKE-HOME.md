# Take the lab to work

**Everything you need to continue is in the [course GitHub repository](https://github.com/parasdoshicom/AI-Data-Analytics).** Open the course companion to revisit the slides or download the kit. Use Code → Download ZIP on GitHub if you want the full source and additional synthetic exercises.

Open the source folder in your existing Codex, Claude Code or Cursor session. From the repository root run `python3 plugins/chatdata/scripts/doctor.py` (Python 3.9 or newer). The five synthetic checks run locally. Your completed weekend project stays in the student folder.

Open that student folder in a fresh chat and paste:

> Read work/model.json, work/workflow.md, work/accepted-rule.json and work/pilot-charter.md. Recalculate the blind-release ticket decision from the CSVs. Show which correction changed the decision, the evidence you used and what would invalidate it. Save a proof another analyst could check.

For a first workplace pilot, substitute one approved extract and name a metric owner. Save the baseline, run your eval suite, and ask a colleague to replay one disputed answer before expanding access.
