"""Prepare an isolated student eval folder and score independent runs."""
import argparse
import csv
import hashlib
import json
import math
import shutil
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "golden/inputs"
REFERENCE = ROOT / "golden/review/reference.json"


def read(path):
    return json.loads(path.read_text())


def prepare(target, questions):
    target.mkdir(parents=True, exist_ok=False)
    for item in INPUTS.iterdir():
        shutil.copyfile(item, target / item.name)
    if questions:
        shutil.copyfile(questions, target / "questions.json")
    for name in ("activation.csv", "incidents.csv", "support.csv"):
        shutil.copyfile(ROOT / "data" / name, target / name)
    print("Open this folder alone in a fresh session:", target.resolve())


def score(reference, runs):
    cases = reference["cases"]
    expected_ids = {c["id"] for c in cases}
    observed = []
    results = {}
    for name, answers in runs:
        indexed = {a["id"]: a for a in answers}
        if set(indexed) != expected_ids or len(indexed) != len(answers):
            raise ValueError(f"{name}: return exactly one response for each reference ID.")
        results[name] = {}
        passed = 0
        for c in cases:
            a = indexed[c["id"]]
            failures = [k for k in ("route","action","numerator","denominator") if a.get(k) != c[k] or k not in a]
            value = a.get("fraction")
            if c["fraction"] is None:
                valid = value is None and "fraction" in a
            else:
                valid = isinstance(value,(float,int)) and not isinstance(value,bool) and math.isclose(value,c["fraction"],abs_tol=reference["fraction_tolerance"],rel_tol=0)
            if not valid:
                failures.append("fraction")
            evidence = a.get("evidence", [])
            if not isinstance(evidence,list) or any(not set(group).intersection(evidence) for group in c["evidence_groups"]):
                failures.append("evidence")
            if not isinstance(a.get("answer"), str) or not a["answer"].strip():
                failures.append("answer")
            print(name,c["id"],"PASS" if not failures else "FAIL " + ", ".join(failures))
            results[name][c["id"]] = not failures
            passed += not failures
        print(f"{name}: {passed}/{len(cases)} structured checks passed")
        observed.append(indexed)
    if len(observed)>1:
        unanimous=0
        for c in cases:
            decisions=Counter((run[c["id"]].get("route"),run[c["id"]].get("action")) for run in observed)
            unanimous += len(decisions)==1
            if len(decisions)>1:
                print("Decision disagreement:", c["id"], dict(decisions))
        print(f"Cross-run route/action agreement: {unanimous}/{len(cases)} cases unanimous")
    print("Human review: read every answer beside the approved meaning and critical failure rubric before certifying.")

    return results


def review_copy(run_path, cases, target):
    answers = {a["id"]: a for a in read(run_path)}
    if answers.keys() != {c["id"] for c in cases}:
        raise ValueError("Run and reference must contain the same cases.")
    digest = hashlib.sha256(run_path.read_bytes()).hexdigest()
    fields = ["run_sha256", "id", "answer", "criterion", "verdict", "reason", "reviewer"]
    with target.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for case in cases:
            writer.writerow(dict(run_sha256=digest, id=case["id"], answer=answers[case["id"]]["answer"], criterion=case["human_check"]))
    print("Grade each reply in", target, "using accept or reject. Give a reason and sign each row.")


def reviewed_score(run_path, sheet, reference):
    with sheet.open(newline="") as stream:
        records = list(csv.DictReader(stream))
    answers = read(run_path)
    cases = reference["cases"]
    structured = score(reference, [(run_path.name, answers)])[run_path.name]
    by_id = {a["id"]: a for a in answers}
    digest = hashlib.sha256(run_path.read_bytes()).hexdigest()
    if {r["id"] for r in records} != set(structured) or len(records) != len(cases):
        raise ValueError("One review per case is required.")
    accepted = 0
    for row in records:
        key = row["id"]
        if row["run_sha256"] != digest or row["answer"] != by_id[key]["answer"]:
            raise ValueError("Review does not match this run: " + key)
        if row["verdict"] not in {"accept", "reject"} or not all(row[k].strip() for k in ("reason","reviewer")):
            raise ValueError("Finish the verdict, reason and reviewer for " + key)
        if not structured[key] or row["verdict"] == "reject":
            print("Return for correction:", key, row["reason"])
        else:
            accepted += 1
    print(f"{accepted}/{len(cases)} passed both structured checks and signed reading.")
    print("Verify the blind-run evidence separately before using this result for release.")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest="step",required=True)
    sub.add_parser("demo")
    prep=sub.add_parser("prepare");prep.add_argument("folder",type=Path);prep.add_argument("--questions",type=Path)
    grade=sub.add_parser("score");grade.add_argument("runs",type=Path,nargs="+");grade.add_argument("--reference",type=Path,default=REFERENCE)
    for command in ("review-copy", "review-score"):
        judge = sub.add_parser(command)
        judge.add_argument("run", type=Path)
        judge.add_argument("sheet", type=Path)
        judge.add_argument("--reference",type=Path,default=REFERENCE)
    args=parser.parse_args()
    if args.step == "review-copy":
        review_copy(args.run, read(args.reference)["cases"], args.sheet)
        return
    if args.step == "review-score":
        reviewed_score(args.run, args.sheet, read(args.reference))
        return
    if args.step=="prepare":
        prepare(args.folder,args.questions)
        return
    reference=read(args.reference if args.step=="score" else REFERENCE)
    if args.step=="score":
        score(reference, [(p.name,read(p)) for p in args.runs])
    else:
        demo=[{k:c[k] for k in ("id","route","action","fraction","numerator","denominator")} |
              {"answer":c["approved"],"evidence":[g[0] for g in c["evidence_groups"]]} for c in reference["cases"]]
        demo[0]["denominator"]=800
        print("Illustrative deliberately wrong replay; this is a scorer demonstration.")
        score(reference,[("demo",demo)])


if __name__=="__main__":
    try:
        main()
    except StopIteration:
        raise SystemExit("Review the required names in the candidate model.")
    except (ValueError, KeyError, OSError) as error:
        raise SystemExit("Review: " + str(error))
