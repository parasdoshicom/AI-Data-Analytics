"""Prepare an isolated student eval folder and score independent runs."""
import argparse
import json
import math
import shutil
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "golden/inputs"
REFERENCE = ROOT / "golden/review/reference.json"


def read(path):
    return json.loads(path.read_text())


def prepare(target, questions):
    target.mkdir(parents=True, exist_ok=False)
    for item in INPUTS.iterdir():
        shutil.copyfile(item, target / item.name)
    if questions:
        shutil.copyfile(questions, target / "questions.json")
    for name in ("activation.csv", "incidents.csv", "support.csv"):
        shutil.copyfile(ROOT / "data" / name, target / name)
    print("Open this folder alone in a fresh session:", target.resolve())


def score(reference, runs):
    cases = reference["cases"]
    expected_ids = {c["id"] for c in cases}
    observed = []
    for name, answers in runs:
        indexed = {a["id"]: a for a in answers}
        if set(indexed) != expected_ids or len(indexed) != len(answers):
            raise ValueError(f"{name}: return exactly one response for each reference ID.")
        passed = 0
        for c in cases:
            a = indexed[c["id"]]
            failures = [k for k in ("route","action","numerator","denominator") if a.get(k) != c[k] or k not in a]
            value = a.get("fraction")
            if c["fraction"] is None:
                valid = value is None and "fraction" in a
            else:
                valid = isinstance(value,(float,int)) and not isinstance(value,bool) and math.isclose(value,c["fraction"],abs_tol=reference["fraction_tolerance"],rel_tol=0)
            if not valid:
                failures.append("fraction")
            evidence = a.get("evidence", [])
            if not isinstance(evidence,list) or any(not set(group).intersection(evidence) for group in c["evidence_groups"]):
                failures.append("evidence")
            if not isinstance(a.get("answer"), str) or not a["answer"].strip():
                failures.append("answer")
            print(name,c["id"],"PASS" if not failures else "FAIL " + ", ".join(failures))
            passed += not failures
        print(f"{name}: {passed}/{len(cases)} structured checks passed")
        observed.append(indexed)
    if len(observed)>1:
        unanimous=0
        for c in cases:
            decisions=Counter((run[c["id"]]["route"],run[c["id"]]["action"]) for run in observed)
            unanimous += len(decisions)==1
            if len(decisions)>1:
                print("Decision disagreement:", c["id"], dict(decisions))
        print(f"Cross-run route/action agreement: {unanimous}/{len(cases)} cases unanimous")
    print("Human review: read every answer beside the approved meaning and critical failure rubric before certifying.")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest="step",required=True)
    sub.add_parser("demo")
    prep=sub.add_parser("prepare");prep.add_argument("folder",type=Path);prep.add_argument("--questions",type=Path)
    grade=sub.add_parser("score");grade.add_argument("runs",type=Path,nargs="+");grade.add_argument("--reference",type=Path,default=REFERENCE)
    args=parser.parse_args()
    if args.step=="prepare":
        prepare(args.folder,args.questions)
        return
    reference=read(args.reference if args.step=="score" else REFERENCE)
    if args.step=="score":
        score(reference, [(p.name,read(p)) for p in args.runs])
    else:
        demo=[{k:c[k] for k in ("id","route","action","fraction","numerator","denominator")} |
              {"answer":c["approved"],"evidence":[g[0] for g in c["evidence_groups"]]} for c in reference["cases"]]
        demo[0]["denominator"]=800
        print("Illustrative deliberately wrong replay; this is a scorer demonstration.")
        score(reference,[("demo",demo)])


if __name__=="__main__":
    main()
