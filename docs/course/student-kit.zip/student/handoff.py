"""Create a separate project with only the inputs for a blind replay."""
import argparse
import shutil
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("destination", type=Path)
parser.add_argument("--release", action="store_true", help="Prepare the Sunday blind release instead of the activation handoff")
args = parser.parse_args()
target = args.destination
root = Path(__file__).resolve().parent
files = [Path("data/activation.csv"), Path("work/model.json"), Path("work/workflow.md")]
if args.release:
    files = [Path("work/blind/incidents.csv"), Path("work/blind/support.csv"),
             Path("work/model.json"), Path("work/accepted-rule.json")]
missing = [str(f) for f in files if not (root / f).is_file()]
if missing:
    raise SystemExit("Complete the handoff first. Missing: " + ", ".join(missing))
if target.exists():
    raise SystemExit("Choose a new folder so earlier student work is preserved.")
target.mkdir(parents=True)
for file in files:
    (target / file.parent).mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / file, target / file)
print("Open this folder as a new project:", target.resolve())
