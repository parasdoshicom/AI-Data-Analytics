"""Give a second analyst only the files needed for the Session 3 replay."""
import argparse
import shutil
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("destination", type=Path)
target = parser.parse_args().destination
root = Path(__file__).resolve().parent
files = [Path("data/activation.csv"), Path("work/model.json"), Path("work/workflow.md")]
missing = [str(f) for f in files if not (root / f).is_file()]
if missing:
    raise SystemExit("Complete the handoff first. Missing: " + ", ".join(missing))
if target.exists():
    raise SystemExit("Choose a new folder so earlier student work is preserved.")
target.mkdir(parents=True)
for file in files:
    (target / file.parent).mkdir(exist_ok=True)
    shutil.copyfile(root / file, target / file)
print("Open this folder as a new project:", target.resolve())
