"""Offline checks for semantic changes, agent evaluations and pilot outcomes."""
import argparse
import csv
import json
import re
import sqlite3
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORG = ROOT / "org"


def rows(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def bridge(path, model):
    data = rows(path)
    sql = "1.0*sum(case when audience='external' then activated else 0 end)/nullif(sum(case when audience='external' then eligible else 0 end),0)"
    if model:
        section = json.loads(model.read_text())["semantic_model"][0]
        metric = next(m for m in section["metrics"] if m["name"] == "activation_external_7d")
        sql = next(d["expression"] for d in metric["expression"]["dialects"] if d["dialect"] == "ANSI_SQL")
    db = sqlite3.connect(":memory:")
    db.execute("create table activation_by_audience(period text,audience text,eligible integer,activated integer,primary key(period,audience))")
    for row in data:
        eligible, activated = int(row["eligible"]), int(row["activated"])
        if not 0 <= activated <= eligible:
            raise ValueError("Invalid counts for " + row["period"])
        db.execute("insert into activation_by_audience values(?,?,?,?)",(row["period"],row["audience"],eligible,activated))
    db.execute("pragma query_only=on")
    unknown = sum(int(r["eligible"]) for r in data if r["audience"] not in {"internal","external"})
    for period in sorted({r["period"] for r in data},reverse=True):
        v1,v2 = db.execute("select 1.0*sum(activated)/sum(eligible), "+sql+" from activation_by_audience where period=?",(period,)).fetchone()
        targets=[r for r in data if r["period"]==period and r["audience"]=="external"]
        n=sum(int(r["eligible"]) for r in targets)
        if n and (v2 is None or abs(v2-sum(int(r["activated"]) for r in targets)/n)>1e-9):
            raise ValueError("Candidate SQL disagrees with the independent external-account count")
        print(f"{period}: all accounts {v1:.2%}; classified external accounts {v2:.2%}")
    print(f"HOLD: {unknown} eligible accounts unclassified" if unknown else "Bridge reconciled. Owners review before promotion.")


def keyed(path):
    data = rows(path)
    by_id = {r["id"]: r for r in data}
    if len(by_id) != len(data):
        raise ValueError("Duplicate ID in " + str(path))
    return by_id


def score(gold, path):
    answers = keyed(path)
    if gold.keys() != answers.keys():
        raise ValueError("Answer IDs must match gold exactly")
    matrix = Counter()
    blockers = []
    for case, expected in gold.items():
        actual = answers[case]
        route = actual["route"]
        matrix[expected["route"],route] += 1
        problems = []
        if route != expected["route"]:
            problems.append("route")
        if actual["evidence_id"] != expected["evidence_id"]:
            problems.append("evidence")
        if actual["discloses_identifier"] != "no" or re.search(r"[\w.+-]+@[\w.-]+\.[A-Za-z]+",actual["answer"]):
            problems.append("identifier")
        if problems:
            print(case, ", ".join(problems))
            if expected["critical"] == "yes" or "identifier" in problems:
                blockers.append(case)
    hits=sum(n for (a,b),n in matrix.items() if a==b)
    print(f"Route accuracy {hits}/{len(gold)}")
    for (a,b),n in sorted(matrix.items()):
        print(f"  {a} -> {b}: {n}")
    print("HOLD: critical cases " + ", ".join(blockers) if blockers else "No automatic critical failures. Human review still required.")
    return {k for k in gold if answers[k]["route"]==gold[k]["route"]}


def pilot():
    data = rows(ORG/"pilot.csv")
    for week in sorted({r["week"] for r in data}):
        period=[r for r in data if r["week"]==week]
        rated=[r for r in period if r["rated"]=="1"]
        audited=[r for r in period if r["sampled"]=="1"]
        positive=sum(r["positive"]=="1" for r in rated)
        verified=sum(r["verified"]=="1" for r in audited)
        print(f"Week {week}: {positive}/{len(rated)} positive; {len(rated)}/{len(period)} rated; {verified}/{len(audited)} independently verified")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("exercise",choices=["bridge","eval","pilot"])
    parser.add_argument("--extract",type=Path,default=ORG/"bridge.csv")
    parser.add_argument("--model",type=Path)
    parser.add_argument("--gold",type=Path,default=ORG/"gold.csv")
    parser.add_argument("--responses",type=Path,default=ORG/"candidate.csv")
    parser.add_argument("--baseline",type=Path,default=ORG/"baseline.csv")
    args=parser.parse_args()
    if args.exercise=="bridge":
        bridge(args.extract,args.model)
    elif args.exercise=="pilot":
        pilot()
    else:
        gold=keyed(args.gold)
        print("Baseline"); old=score(gold,args.baseline)
        print("Candidate"); new=score(gold,args.responses)
        print("Fixed routes:",sorted(new-old),"Regressed routes:",sorted(old-new))


if __name__=="__main__":
    main()
