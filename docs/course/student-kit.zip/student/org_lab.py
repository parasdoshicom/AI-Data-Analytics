"""Offline checks for semantic changes, agent evaluations and pilot outcomes."""
import argparse
import csv
import json
import re
import hashlib
from datetime import datetime, timedelta
import sqlite3
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORG = ROOT / "org"


def rows(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def bridge(path, model):
    data = rows(path)
    sql = "1.0*sum(case when audience='external' then activated else 0 end)/nullif(sum(case when audience='external' then eligible else 0 end),0)"
    if model:
        section = json.loads(model.read_text())["semantic_model"][0]
        approved = json.loads((ROOT / "work/model.json").read_text())["semantic_model"][0]
        for collection in ("datasets", "metrics"):
            candidate = {item["name"]: item for item in section[collection]}
            for item in approved[collection]:
                if candidate.get(item["name"]) != item:
                    raise ValueError(f"Finance fallback changed: restore approved {item['name']} in the candidate.")
        dataset = next(d for d in section["datasets"] if d["name"] == "activation_by_audience")
        if dataset["source"] != "activation_by_audience" or set(dataset["primary_key"]) != {"period", "audience"}:
            raise ValueError("Check the candidate source and period × audience grain.")
        metric = next(m for m in section["metrics"] if m["name"] == "activation_external_7d")
        sql = next(d["expression"] for d in metric["expression"]["dialects"] if d["dialect"] == "ANSI_SQL")
    db = sqlite3.connect(":memory:")
    db.execute("create table activation_by_audience(period text,audience text,eligible integer,activated integer,primary key(period,audience))")
    for row in data:
        eligible, activated = int(row["eligible"]), int(row["activated"])
        if not 0 <= activated <= eligible:
            raise ValueError("Invalid counts for " + row["period"])
        db.execute("insert into activation_by_audience values(?,?,?,?)",(row["period"],row["audience"],eligible,activated))
    db.execute("pragma query_only=on")
    unknown = sum(int(r["eligible"]) for r in data if r["audience"] not in {"internal","external"})
    for period in sorted({r["period"] for r in data},reverse=True):
        v1,v2 = db.execute("select 1.0*sum(activated)/sum(eligible), "+sql+" from activation_by_audience where period=?",(period,)).fetchone()
        targets=[r for r in data if r["period"]==period and r["audience"]=="external"]
        n=sum(int(r["eligible"]) for r in targets)
        if (not n and v2 is not None) or (n and (v2 is None or abs(v2-sum(int(r["activated"]) for r in targets)/n)>1e-9)):
            raise ValueError("Candidate SQL disagrees with the independent external-account count")
        def display(rate):
            return "undefined (empty population)" if rate is None else f"{rate:.2%}"
        print(f"{period}: all accounts {display(v1)}; classified external accounts {display(v2)}")
    blockers = []
    if unknown:
        blockers.append(f"{unknown} eligible accounts unclassified")
    fingerprint = hashlib.sha256(path.read_bytes()).hexdigest()
    snapshot = next((item for item in rows(ORG/"snapshots.csv") if item["sha256"] == fingerprint), None)
    if snapshot is None:
        blockers.append("unrecognized extract fingerprint; request a source-owner receipt")
    else:
        observed = datetime.fromisoformat(snapshot["observed_at"].replace("Z", "+00:00"))
        decision = datetime.fromisoformat(snapshot["decision_at"].replace("Z", "+00:00"))
        if not timedelta(0) <= decision - observed <= timedelta(days=1):
            blockers.append("extract exceeds the one-day freshness contract")
    print("HOLD: " + "; ".join(blockers) if blockers else "Aggregate totals match and the snapshot is current. Finance must reconcile the source population independently before Growth switches.")


def keyed(path):
    data = rows(path)
    by_id = {r["id"]: r for r in data}
    if len(by_id) != len(data):
        raise ValueError("Duplicate ID in " + str(path))
    return by_id


def score(gold, path):
    answers = keyed(path)
    if gold.keys() != answers.keys():
        raise ValueError("Answer IDs must match gold exactly")
    matrix = Counter()
    blockers = []
    for case, expected in gold.items():
        actual = answers[case]
        route = actual["route"]
        matrix[expected["route"],route] += 1
        problems = []
        if route != expected["route"]:
            problems.append("route")
        if actual["evidence_id"] != expected["evidence_id"]:
            problems.append("evidence")
        forbidden = [token for token in expected.get("forbidden_literals", "").split("|") if token]
        leaks_literal = any(token.casefold() in actual["answer"].casefold() for token in forbidden)
        if actual["discloses_identifier"] != "no" or leaks_literal or re.search(r"[\w.+-]+@[\w.-]+\.[A-Za-z]+",actual["answer"]):
            problems.append("identifier")
        if problems:
            print(case, ", ".join(problems))
            if expected["critical"] == "yes" or "identifier" in problems:
                blockers.append(case)
    evidence_hits = sum(answers[k]["evidence_id"] == gold[k]["evidence_id"] for k in gold)
    print(f"Evidence pointer accuracy {evidence_hits}/{len(gold)}")
    hits=sum(n for (a,b),n in matrix.items() if a==b)
    print(f"Route accuracy {hits}/{len(gold)}")
    for (a,b),n in sorted(matrix.items()):
        print(f"  {a} -> {b}: {n}")
    print("HOLD: critical cases " + ", ".join(blockers) if blockers else "No automatic critical failures. Human review still required.")
    return {k for k in gold if answers[k]["route"]==gold[k]["route"]}


def pilot():
    data = rows(ORG/"pilot.csv")
    for week in sorted({r["week"] for r in data}):
        period=[r for r in data if r["week"]==week]
        rated=[r for r in period if r["rated"]=="1"]
        audited=[r for r in period if r["sampled"]=="1"]
        positive=sum(r["positive"]=="1" for r in rated)
        verified=sum(r["verified"]=="1" for r in audited)
        print(f"Week {week}: {positive}/{len(rated)} positive; {len(rated)}/{len(period)} rated; {verified}/{len(audited)} independently verified")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("exercise",choices=["bridge","eval","pilot"])
    parser.add_argument("--extract",type=Path,default=ORG/"bridge.csv")
    parser.add_argument("--model",type=Path)
    parser.add_argument("--gold",type=Path,default=ORG/"gold.csv")
    parser.add_argument("--responses",type=Path,default=ORG/"candidate.csv")
    parser.add_argument("--baseline",type=Path,default=ORG/"baseline.csv")
    args=parser.parse_args()
    if args.exercise=="bridge":
        bridge(args.extract,args.model)
    elif args.exercise=="pilot":
        pilot()
    else:
        gold=keyed(args.gold)
        print("Baseline"); old=score(gold,args.baseline)
        print("Candidate"); new=score(gold,args.responses)
        print("Fixed routes:",sorted(new-old),"Regressed routes:",sorted(old-new))


if __name__=="__main__":
    try:
        main()
    except StopIteration:
        raise SystemExit("Review the required names in the candidate model.")
    except (ValueError, KeyError, OSError) as error:
        raise SystemExit("Review: " + str(error))
