# Which piece of the activation review should the agent do?

What can Growth or Engineering decide this week? Who has authority to act?

Which part of that work repeats? How would another analyst check it from the same source?

What observation would make the decision owner change their call?

Write the first job you would give the agent and one decision you would keep with a person. Give your partner enough detail to object.

For example, Growth requests the same activation brief before each release review. Ask the agent to calculate the before and after counts for mature cohorts and show its source. The engineering lead decides what to do about the rollout. Say what more the lead needs before taking action.
