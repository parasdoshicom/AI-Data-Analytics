# A decision worth the analysis

Who can act, and by when?
What are their two realistic options?
Which observation would make them switch?
What would you do if the evidence were missing?
Which tempting metric can you skip because it would leave the choice unchanged?

Example: On Friday the support lead can keep the usual Saturday shift or add one specialist for 10 AM–noon. Check how many tickets miss the response promise during that window and whether another specialist could handle them. A weekly ticket total alone cannot settle the staffing question.
