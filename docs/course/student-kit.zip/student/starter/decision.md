# A decision worth the analysis

Who can act, and by when?
What are their two realistic options?
Which observation would make them switch?
What would you do if the evidence were missing?
Which tempting metric can you skip because it would leave the choice unchanged?

Example: On Friday the support lead can keep the usual Saturday shift or add one specialist for 10 AM–noon. In this exercise, request the specialist if at least eight late first replies waited for specialist help during that window. Otherwise keep the regular roster. If the wait reason is missing, ask Support Operations to check the tickets before changing the shift. A weekly ticket total alone cannot settle the staffing question.
