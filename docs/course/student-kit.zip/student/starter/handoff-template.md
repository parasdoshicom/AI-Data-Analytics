# Peer handoff

Decision the user is trying to make:
Approved metric name, version and owner:
Source, observation period and grain:
Reproducible calculation:
Counts and result:
One claim the data cannot establish:
Next evidence, decision owner and review date:

For an independent run, give the next analyst only the approved model, input and workflow. Ask them to record their own answer before opening this proof.
