# Peer handoff

Who is waiting for an answer? What will they do with it?
Approved metric name, version and owner:
Source, observation period and grain:
Reproducible calculation:
Counts and result:
One claim the data cannot establish:
What would change your call? Who will check, and when?

For an independent run, give the next analyst only the approved model, input and workflow. Ask them to record their own answer before opening this proof.
