# Change and release decision

Old behavior / proposed behavior:
Observed failure and trace ID:
Dataset, model and eval versions:
Who owns the definition / source / consumer:
Measured before and after, including denominators:
Adversarial or held-out test (seal expected result before running):
Reviewer and disposition:
Canary scope, rollback trigger and exact file or consumer pointer to restore:
Next review date:
