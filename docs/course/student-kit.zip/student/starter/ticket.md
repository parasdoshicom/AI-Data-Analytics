# [release / platform / flow]

Owner and reviewer:
Decision and status:
Affected attempts / eligible attempts:
Observed symptom and matching reproduction ID:
Alternative explanation tested:
Action requested:
Acceptance rule and next release to inspect:
Follow-up evidence, owner decision and remaining uncertainty:
Correction sent back to Product Data:
