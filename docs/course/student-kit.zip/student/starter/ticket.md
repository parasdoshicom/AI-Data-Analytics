# [release / platform / flow]

Owner and reviewer:
Decision and status:
Affected attempts / eligible attempts:
Observed symptom and matching reproduction ID:
What else could explain this? How did you check?
Action requested:
Acceptance rule and next release to inspect:
What happened after the fix? Who decided whether to close the ticket, and what still needs checking?
Correction sent back to Product Data:
