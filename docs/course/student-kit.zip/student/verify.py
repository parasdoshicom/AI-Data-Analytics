"""Offline reference checks for the Maven activation and import lab (Python 3)."""
import argparse
import csv
import json
import math
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def read_json(path):
    return json.loads(path.read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_section():
    model = read_json(ROOT / "work/model.json")
    require(model["version"] == "0.2.0.dev0", "Use the course OSI version.")
    section, = model["semantic_model"]
    return section


def check_model():
    section = load_section()
    table = next(t for t in section["datasets"] if t["name"] == "activation")
    metric = next(m for m in section["metrics"] if m["name"] == "activation_7d")
    require(table["source"] == "activation" and set(table["primary_key"]) == {"period", "segment"}, "Check source and grain.")
    require(metric["name"] == "activation_7d", "Check metric identity.")
    context = json.loads(next(x["data"] for x in metric["custom_extensions"] if x["vendor_name"] == "CHATDATA"))
    require(context.get("owner") and context.get("unit") == "fraction", "Name a metric owner and use fraction units.")
    sql = next(x["expression"] for x in metric["expression"]["dialects"] if x["dialect"] == "ANSI_SQL")
    db = sqlite3.connect(":memory:")
    db.execute("create table activation(period text, segment text, eligible integer, activated integer, primary key(period, segment))")
    rows = read_csv(ROOT / "data/activation.csv")
    for r in rows:
        require(0 <= int(r["activated"]) <= int(r["eligible"]), "Review invalid counts before reporting.")
        db.execute("insert into activation values (?,?,?,?)", [r[k] for k in ("period","segment","eligible","activated")])
    db.execute("insert into activation values ('empty','new',0,0)")
    db.execute("insert into activation values ('test','new',3,2)")
    db.execute("pragma query_only = ON")
    for period, target in (("before", .68), ("after", .37), ("empty", None), ("test", 2/3)):
        result = db.execute("select " + sql + " from activation where period = ?", (period,)).fetchone()[0]
        require(result is None if target is None else result is not None and math.isclose(result, target), "Metric failed cohort or empty-denominator check.")
    print("MODEL PASS — 680/1000 and 370/1000; empty denominator and independent cohort checked.")


def approved_server_rate():
    section = load_section()
    table = next(t for t in section["datasets"] if t["name"] == "incidents")
    require(table["source"] == "incidents" and set(table["primary_key"]) == {"release", "platform"}, "Check incident source and grain.")
    metric = next(m for m in section["metrics"] if m["name"] == "import_server_failure_rate")
    extension = next(x for x in metric["custom_extensions"] if x["vendor_name"] == "CHATDATA")
    require(json.loads(extension["data"]).get("owner"), "Name the incident metric owner.")
    sql = next(x["expression"] for x in metric["expression"]["dialects"] if x["dialect"] == "ANSI_SQL")
    db = sqlite3.connect(":memory:")
    def calculate(server, attempts, client):
        query = "with incidents as (select ? as server_errors, ? as attempts, ? as client_errors) select " + sql + " from incidents"
        return db.execute(query, (server, attempts, client)).fetchone()[0]
    require(math.isclose(calculate(3, 20, 9), .15) and calculate(0, 0, 0) is None, "Check approved server rate and zero denominator.")
    return calculate


def triage(incidents, support, rule):
    evidence = {}
    for observation in support:
        if observation["test"] == "onboarding_import":
            evidence.setdefault((observation["release"], observation["platform"]), []).append(observation)
    calculate = approved_server_rate() if rule else None
    for r in incidents:
        key = r["release"], r["platform"]
        attempts, client, server = (int(r[k]) for k in ("attempts","client_errors","server_errors"))
        require(0 <= client <= attempts and 0 <= server <= attempts and attempts > 0, "Review counts.")
        matches = evidence.get(key, [])
        test = matches[0] if len(matches) == 1 else {}
        if rule:
            signal = calculate(server, attempts, client) >= rule["server_rate_min"] and test.get("result") == "reproduced"
        else:
            signal = client / attempts >= .10
        route = "product ticket candidate" if signal else "telemetry review" if client / attempts >= .10 else "monitor"
        if rule and calculate(server, attempts, client) >= rule["server_rate_min"] and not signal:
            route = "human review: corroboration missing or conflicting"
        print(f"{key[0]} / {key[1]} / {route} / server {server}/{attempts} / support {test.get('id','missing')}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", choices=["ready","model","triage"])
    parser.add_argument("--release", default="R17")
    parser.add_argument("--approved", action="store_true")
    parser.add_argument("--data", type=Path, default=ROOT / "data")
    args = parser.parse_args()
    if args.step == "ready":
        for name in ("data/activation.csv","data/incidents.csv","data/support.csv","starter/model.json"):
            require((ROOT/name).is_file(), "Missing " + name)
        receipt = ROOT / "work/ready.txt"
        if receipt.exists():
            header = read_csv(ROOT / "data/activation.csv")[0].keys()
            require(all(name in receipt.read_text().lower() for name in header), "Open work/ready.txt and compare all four column names with the CSV.")
            print("READY — kit present and saved header confirmed.")
        else:
            print("Kit present. Run the readiness prompt and reopen work/ready.txt to confirm agent file access.")
    if args.step == "model":
        check_model()
    if args.step == "triage":
        rule = None
        if args.approved:
            rule = read_json(ROOT / "work/accepted-rule.json")
            require(rule["status"] == "accepted" and rule["reviewer"].strip() and rule["source"] == "S102", "A reviewed engineering correction is required.")
            require(rule["require_matching_reproduction"] is True and rule["server_rate_min"] == .10, "Review rule against the agreed lab policy.")
        rows = [r for r in read_csv(args.data / "incidents.csv") if r["release"] == args.release]
        require(rows, "No observations for this release.")
        triage(rows, read_csv(args.data / "support.csv"), rule)


if __name__ == "__main__":
    try:
        main()
    except StopIteration:
        raise SystemExit("REVIEW — check the required dataset name, metric name, CHATDATA extension and ANSI_SQL dialect in work/model.json.")
    except (KeyError, TypeError, ValueError, OSError, sqlite3.Error) as error:
        raise SystemExit("REVIEW — " + str(error))
